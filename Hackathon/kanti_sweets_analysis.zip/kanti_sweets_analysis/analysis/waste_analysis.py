import matplotlib.pyplot as plt
def most_wasted_sweet(df):
    total_sales = df.groupby('sweet_name')['quantity_sold'].sum().sort_values()
    total_sales.plot(kind='barh', color='tomato', figsize=(10, 6))
    plt.title("Least to Most Sold Sweets in the whole year ")
    plt.xlabel("Total Quantity Sold")
    plt.ylabel("Sweet Name")
    plt.tight_layout()
    plt.show()

