import matplotlib.pyplot as plt

def sweet_sales_pm(df, month):
    df_month = df[df['month'] == month]
    sweet_totals = df_month.groupby('sweet_name')['quantity_sold'].sum()
    sweet_totals.plot.pie(autopct='%1.1f%%', startangle=90, figsize=(7,7))
    plt.title(f"Top Selling Sweets in Month {month}")
    plt.ylabel("")
    plt.tight_layout()
    plt.show()
