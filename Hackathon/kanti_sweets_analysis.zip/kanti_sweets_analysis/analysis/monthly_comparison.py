import seaborn as sns
import matplotlib.pyplot as plt

def monthly_sales_bar(df):
    monthly_sales = df.groupby(['month'])['quantity_sold'].sum()
    sns.barplot(x=monthly_sales.index, y=monthly_sales.values, palette='muted')
    plt.title("Monthly Total Sweet Sales")
    plt.xlabel("Month")
    plt.ylabel("Quantity Sold")
    plt.tight_layout()
    
    plt.show()

def monthly_sales_by_sweet(df):
    pivot = df.pivot_table(values='quantity_sold', index='month', columns='sweet_name', aggfunc='sum').fillna(0)
    pivot.plot(kind='bar', stacked=True, figsize=(12, 6))
    plt.title("Monthly Sweet Sales Comparison")
    plt.xlabel("Month")
    plt.ylabel("Quantity Sold")
    plt.tight_layout()
    plt.show()
