def highest_revenue_month(df):
    monthly_revenue = df.groupby('month')['revenue'].sum()
    best_month = monthly_revenue.idxmax()
    best_value = monthly_revenue.max()
    print(f"📈 Highest Revenue Month: {best_month} with ₹{best_value}")
