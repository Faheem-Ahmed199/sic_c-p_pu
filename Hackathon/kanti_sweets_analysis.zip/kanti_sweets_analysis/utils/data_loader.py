import pandas as pd

def load_data(filepath='data/kanti_sweets_dummy_sales_data.csv'):
    df = pd.read_csv(filepath, parse_dates=['date'])
    df['month'] = df['date'].dt.month
    df['year'] = df['date'].dt.year
    return df
