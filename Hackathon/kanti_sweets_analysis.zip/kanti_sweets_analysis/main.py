from utils.data_loader import load_data
from analysis.top_selling_sweet import sweet_sales_pm
from analysis.revenue_peak import highest_revenue_month
from analysis.monthly_comparison import monthly_sales_bar, monthly_sales_by_sweet
from analysis.waste_analysis import most_wasted_sweet


def menu():
    print("\n-------- KANTI SWEETS SALES ANALYSIS MENU ---------")
    print("1. Sweet that sells more in a specific month ")
    print("2. Month with highest revenue")
    print("3. Monthly total sales ")
    print("4. Most wasted sweet ")
    print("5. Monthly sweet-wise comparison ")
    print("0. Exit")

def main():
    df = load_data()
    while True:
        menu()
        choice = input("Enter your choice (0–5): ")

        if choice == '1':
            month = int(input("Enter month number (1–12): "))
            sweet_sales_pm(df, month)
        elif choice == '2':
            highest_revenue_month(df)
        elif choice == '3':
            monthly_sales_bar(df)
        elif choice == '4':
            most_wasted_sweet(df)
        elif choice == '5':
            monthly_sales_by_sweet(df)
        
        
        elif choice == '0':
            print("Thank you!!")

            break
        else:
            print("Invalid choice. Please select between 0–5.")

if __name__ == "__main__":
    main()
